<html>
<?php
 $serverName = "localhost"; //serverName\instanceName
 $connectionInfo = array( "Database"=>"ELearning", "UID"=>"sa", "PWD"=>"root");
 $conn = sqlsrv_connect( $serverName, $connectionInfo);

 if( $conn === false ) {
     die( print_r( sqlsrv_errors(), true));
 }


$AccountId= $_REQUEST['AccountId'];

 
$query  = "DELETE FROM USER_ACCOUNT WHERE AccountId= $AccountId" ;

sqlsrv_query($conn, $query);


?>
<body style="background: #F7FF93; padding-top: 40px; font-family: Helvetica">
<a style="color: #000;
                           text-decoration: none;
                           cursor: pointer;
                           border: 1px solid #1b2432;
                           padding: 5px 10px;
                           border-radius: 5px;" href='login.php'>Login</a>
                           <br/>
                           <br/>
                           <br/>
<div style='border: 1px solid #ccc; width: 100%; height:10%; margin 0 auto;  border-radius: 0px; display: flex; color: #fff; background: #61A4BC; align-items: center;justify-content: center;'> User <?php echo($AccountId) ?> has been deleted ! </div> <br/>
</body>

</html>