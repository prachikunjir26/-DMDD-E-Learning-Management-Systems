<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./css/login.css">
</head>
<body style='background: #40DFEF';>
<div style='margin-left: -13px;
                                    margin-right: -14px;
                                    margin-top:-18px;
                                    border-radius: 0px;
                                    display: flex;
                                    color: #fff;
                                    background: #40DFEF;
                                    align-items: center;
                                    justify-content: center;'>
								 <h2>Welcome To Elearning</h2>
                                </div>

<fieldset>
    <h2 class="fs-title">Login</h2>
    <!-- <input type="text" name="email" placeholder="Username" /><br>
    <input type="password" name="pass" placeholder="Password" /><br> -->
    <div class="dropdown">
    <button class="dropbtn">Actions 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="admin.php">Admin</a>
      <!-- <a href="instructor.php">Instructor</a>
      <a href="learner.php">Learner</a> -->
    </div>
  </div> 
</div>

<div class="dropdown">
    <button class="dropbtn">Sign Up 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="signup.php">Add User</a>
      <!-- <a href="instructor.php">Instructor</a>
      <a href="learner.php">Learner</a> -->
    </div>
  </div> 
</div>
   
  </fieldset>
  
                                 
  </body>
</html>