

<html>
    <body style="background: #FFFBE7; padding-top: 40px; padding-left: 380px; font-family: Helvetica; width:50%;">
<form action="insert.php" method="post">

<h3 style="padding-left: 250px;">Add User Details</h3>

<fieldset style="background: white;
  border: 0 none;
  border-radius: 3px;
  box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
  padding: 20px 30px;
  box-sizing: border-box;
  width: 80%;
  margin: 0 10%;">
    <h3
    style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;">
    </h3>
    <input type = 'text' placeholder="Username" name='Username_tf' 
            style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;"/><br>
    <input type = 'text' placeholder="Password" name='Password_tf' 
    
            style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;" /><br>
    <input type = 'text' placeholder="FirstName" name='FName_tf' 
            style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;" /><br>
   <input type = 'text' placeholder="LastName" name='LName_tf' 
            style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;" /><br>
    <input type = 'text' placeholder="EmailId" name='EmailId_tf' 
            style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;"/><br>
    <input type = 'text' placeholder="Contact Number" name='Contact_tf' 
    style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;"/><br>
    <input type = 'text' placeholder="Date" name='Date_tf' 
    style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;"/><br>
    <input type = 'text' placeholder="Account Type" name='Account_tf' 
    style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;"/><br>
            <input type = 'submit' style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;">
  </fieldset>

</form>

</body>
 </html>






