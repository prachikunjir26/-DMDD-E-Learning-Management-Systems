<?php

$serverName = "localhost"; //serverName\instanceName
$connectionInfo = array( "Database"=>"ELearning", "UID"=>"sa", "PWD"=>"root");
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn === false ) {
    die( print_r( sqlsrv_errors(), true));
}

//$sql=("insert into [USER_ACCOUNT] ( [AccountUsername], [AccountPassword], [FirstName], [LastName], [EmailId], [ContactNo], [CreatedOn], [AccountType]) 
//  VALUES ('{$_POST['Username_tf']}','{$_POST['Password_tf']}','{$_POST['FName_tf']}','{$_POST['LName_tf']}','{$_POST['EmailId_tf']}','{$_POST['Contact_tf']}','{$_POST['Date_tf']}','{$_POST['Account_tf']}')");

  $sql = "insert into [USER_ACCOUNT] ( [AccountUsername], [AccountPassword], [FirstName], [LastName], [EmailId], [ContactNo], [CreatedOn], [AccountType]) VALUES (?,?,?,?,?,?,?,?)";
 $params = array( "{$_POST['Username_tf']}","{$_POST['Password_tf']}","{$_POST['FName_tf']}","{$_POST['LName_tf']}","{$_POST['EmailId_tf']}","{$_POST['Contact_tf']}","{$_POST['Date_tf']}","{$_POST['Account_tf']}");

// $sql=("OPEN SYMMETRIC KEY AccountPass_SM
// DECRYPTION BY CERTIFICATE AccountPass;


// declare @sam varchar(100), @dec varbinary(400),@ans varchar(100)
// set @sam = '{$_POST['Password_tf']}'
// set @dec= dbo.ENCRYPT_PASSWORD(@sam)
// select dbo.DECRYPT_PASSWORD(@dec) as Decrpyted_PWD

// ");
// $params = array("{$_POST['Password_tf']}");


 $stmt = sqlsrv_query( $conn, $sql, $params);
//  $row = sqlsrv_fetch_array($stmt);
if( $stmt === false ) {
     die( print_r( sqlsrv_errors(), true));
}

 

$uname =  "{$_POST['Username_tf']} ";

 

 

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body style="background: #F7FF93; padding-top: 40px; font-family: Helvetica">
<a style="color: #000;
                           text-decoration: none;
                           cursor: pointer;
                           border: 1px solid #1b2432;
                           padding: 5px 10px;
                           border-radius: 5px;" href='login.php'>Login</a>
                           <br/>
                           <br/>
                           <br/>
<div style='border: 1px solid #ccc; width: 100%; height:50px; margin 0 auto;  border-radius: 0px; display: flex; color: #fff; background: #61A4BC; align-items: center;justify-content: center;'> User <?php echo($uname) ?> has been added ! </div> <br/>
</body>
</html>