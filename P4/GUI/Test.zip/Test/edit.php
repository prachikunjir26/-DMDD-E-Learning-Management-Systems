<?php

    $serverName = "localhost"; //serverName\instanceName
    $connectionInfo = array( "Database"=>"ELearning", "UID"=>"sa", "PWD"=>"root");
    $conn = sqlsrv_connect( $serverName, $connectionInfo);

    if( $conn === false ) {
        die( print_r( sqlsrv_errors(), true));
    }


$AccountId= $_REQUEST['AccountId'];
$query = "SELECT * FROM [USER_ACCOUNT] where AccountId='$AccountId' ";
$result= sqlsrv_query($conn,$query) or die('Query failed: ' . sqlsrv_error());
$row = sqlsrv_fetch_array($result);
if($row!= NULL)
{
?>

<html>
    <body style="background: #F7FF93; padding-top: 40px; padding-left: 380px; font-family: Helvetica; width:50%;">
    <!-- <body style="background: #efe5dc; padding: 20px; font-family: Helvetica"> -->
<a style="color: #000;
                           text-decoration: none;
                           cursor: pointer;
                           border: 1px solid #1b2432;
                           padding: 5px 10px;
                           border-radius: 5px;" href='login.php'> Login Page</a><br/>
<center>


<h2>Edit User Details for Account Id:  <?php echo($AccountId)?> </h2>
                                                                                                    

<form  action="editlogic.php" method="POST">
<table cellpadding=2 cellspacing=2 border="0">

<tr>
<th style="text-align: left">Account ID: </th>
<td><input style="border: none; width: 200px; height: 30px; border-radius: 5px; padding: 5px" name="AccountId" type="text" value="<?php echo $row['AccountId']; ?>"></td>
</tr>

<tr>
<th style="text-align: left">Username: </th>
<td><input style="border: none; width: 200px; height: 30px; border-radius: 5px; padding: 5px" name="Username_tf" type="text" value="<?php echo $row['AccountUsername']; ?>"></td>
</tr>

<tr>
<th style="text-align: left">Password: </th>
<td><input style="border: none; width: 200px; height: 30px; border-radius: 5px; padding: 5px" name="Password_tf" type="text" value="<?php echo $row['AccountPassword']; ?>"></td>
</tr>


<tr>
<th style="text-align: left">First Name: </th>
<td><input style="border: none; width: 200px; height: 30px; border-radius: 5px; padding: 5px" name="FName_tf" type="text" value="<?php echo $row['FirstName']; ?>"></td>
</tr>

<tr>
<th style="text-align: left">Last Name: </th>
<td><input style="border: none; width: 200px; height: 30px; border-radius: 5px; padding: 5px" name="LName_tf" type="text" value="<?php echo $row['LastName']; ?>"></td>
</tr>

<tr>
<th style="text-align: left">EmailId</th>
<td><input style="border: none; width: 200px; height: 30px; border-radius: 5px; padding: 5px" name="EmailId_tf" type="text" value="<?php echo $row['EmailId']; ?>"></td>
</tr>

<tr>
<th style="text-align: left">User Type</th>
<td><input style="border: none; width: 200px; height: 30px; border-radius: 5px; padding: 5px" name="Contact_tf" type="text" value="<?php echo $row['AccountType']; ?>"></td>
</tr>


<tr>
</tr>
<tr>
<td><input style="width: 150px; height: 40px; border-radius: 5px; color: #fff; background: #557B83; font-size: 16px; margin: 0 auto;" type="submit" value="Update" /></td>

</tr>

</form>
</body>

</center>

</html>
<?php
}
?>



