<?php
?>
<html>
    <body style="background: #F7FF93; padding-top: 40px; padding-left: 333px; font-family: Helvetica; width:50%;"></body>
<!-- <form action="insert.php" method="post"> -->
<div style='margin-left: -13px;
                                    width: 100%;
                                    margin-right: -14px;
                                    margin-top:-18px;
                                    border-radius: 0px;
                                    display: flex;
                                    color: #fff;
                                    background: #40DFEF;
                                    align-items: center;
                                    justify-content: center;'>
								 <h2>Welcome To Elearning Sign up page</h2>
                                </div>
</div>
    <div style='border: 1px solid #ccc; width: 100%; margin 0 50px; margin-top:100px;  border-radius: 10px; display: flex; color: #fff; background: #069A8E; align-items: center;justify-content: center;'>
    <a style="text-decoration: none; color: #fff; letter-spacing: 1px; line-height: 2; text-align: center"  href='adduser.php'><h2>Add User</h2></a>
    </div>
    <br>
    <br>
    
    <!-- <form style="margin-top: 30px" action='search.php' method='POST'>
                                 <input style="border: none; width: 80%; height: 30px; border-radius: 5px; padding: 5px; margin-right: 10px"  type ='text' placeholder="Enter User Details" name='searchtext' value='searchtext'>
								 <input style="border: none;
                                               width: 100px;
                                               height: 30px;
                                               border-radius: 5px;
                                               padding: 5px;
                                               background: #6c757d;
                                               letter-spacing: 0.5px;
                                               font-weight: bold;
                                               color: #fff;" type='submit' value='Search'>

								 </form> -->

<!-- </form>     -->
</html>