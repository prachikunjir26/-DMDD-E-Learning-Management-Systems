<?php
$serverName = "localhost"; //serverName\instanceName
$connectionInfo = array( "Database"=>"ELearning", "UID"=>"sa", "PWD"=>"root");
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn === false ) {
    die( print_r( sqlsrv_errors(), true));
}

?>

<html>
<body style="background: #F7FF93; padding: 20px; font-family: Helvetica">
<a style="color: #000;
                           text-decoration: none;
                           cursor: pointer;
                           border: 1px solid #1b2432;
                           padding: 5px 10px;
                           border-radius: 5px;" href='login.php'>Login</a><br/>
<center>

<h2 style="letter-spacing: 0.5px">SEARCH RESULTS</h2>
<table style="border: 1px solid #ccc;
              padding: 5px;
              border-radius: 5px;">
<tr>
<th style="height: 40px; background:#9FB4FF; color: #fff; padding: 10px; font-size: 14px">AccountId</th>
<th style="height: 40px; background:#9FB4FF; color: #fff; padding: 10px; font-size: 14px">Username</td>
<th style="height: 40px; background:#9FB4FF; color: #fff; padding: 10px; font-size: 14px">Password</td>
<th style="height: 40px; background:#9FB4FF; color: #fff; padding: 10px; font-size: 14px">FName</td>
<th style="height: 40px; background:#9FB4FF; color: #fff; padding: 10px; font-size: 14px">LName</td>
<th style="height: 40px; background:#9FB4FF; color: #fff; padding: 10px; font-size: 14px">EmailId</td>
<th style="height: 40px; background:#9FB4FF; color: #fff; padding: 10px; font-size: 14px">Account</td>
<th style="height: 40px; background:#9FB4FF; color: #fff; padding: 10px; font-size: 14px">Manage Data</td>
</tr>
<?php
$search = isset($_POST['searchtext']) ? $_POST['searchtext'] : "";
echo($search);
$query = "SELECT * FROM USER_ACCOUNT";

$stmt = sqlsrv_query( $conn, $query );
if( $stmt === false) {
    die( print_r( sqlsrv_errors(), true) );
}

while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
?>

<tr style="height: 40px; text-align: center; font-size: 14px; letter-spacing: 1px; border-bottom: 1px solid #fff">
<td><?php echo $row['AccountId']; ?></td>
<td><?php echo $row['AccountUsername']; ?></td>
<td><?php echo $row['AccountPassword']; ?></td>
<td><?php echo $row['FirstName']; ?></td>
<td><?php echo $row['LastName']; ?></td>
<td><?php echo $row['EmailId']; ?></td>
<td><?php echo $row['AccountType']; ?></td>
<td><a style="
              padding: 5px 10px;
              border-radius: 5px;
              background: #557B83;
              opacity: 0.7;
              text-decoration: none;
              cursor: pointer;
              color: #fff;" href="edit.php?AccountId=<?php echo $row['AccountId']; ?>">Edit</a>&nbsp;
<a style=" padding: 5px 10px;
                        border-radius: 5px;
                        background: #557B83;
                        opacity: 0.7;
                        text-decoration: none;
                        cursor: pointer;
                        color: #fff;"  href="delete.php?AccountId=<?php echo $row['AccountId']; ?>">Delete</a>
 </td>
</tr>





<?php
  }  //end of while



  //end of else i.e match is found
 ?>
</table>


</center>

</body>
</html>
