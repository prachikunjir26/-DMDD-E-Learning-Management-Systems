<?php
?>
<html>
    <body style="background: #FFFBE7; padding-top: 40px; padding-left: 380px; font-family: Helvetica; width:50%;"></body>
<form action="insert.php" method="post">

<h3 style="padding-left: 250px;">Add Course Details</h3>
<h3> </h3>
<fieldset style="background: white;
  border: 0 none;
  border-radius: 3px;
  box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
  padding: 20px 30px;
  box-sizing: border-box;
  width: 80%;
  margin: 0 10%;">
    <h3
    style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;">
    </h3>
    <input type = 'text' placeholder="Coursename" name='Studentname_tf' 
            style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;"/><br>
    <input type = 'text' placeholder="Coursefees" name='Password_tf' 
    
            style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;" /><br>
    <input type = 'text' placeholder="InstructorId" name='Name_tf' 
            style="font-weight: normal;
            font-size: 13px;
            color: #666;
            margin-bottom: 20px;" /><br>
    
  </fieldset>

</form>
</html>






