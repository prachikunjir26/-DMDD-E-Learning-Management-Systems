<html>
    <?php

    $serverName = "localhost"; //serverName\instanceName
    $connectionInfo = array( "Database"=>"ELearning", "UID"=>"sa", "PWD"=>"root");
    $conn = sqlsrv_connect( $serverName, $connectionInfo);

    if( $conn === false ) {
        die( print_r( sqlsrv_errors(), true));
    }


   
$AccountId= $_REQUEST['AccountId'];

$AccountId=$_POST['AccountId'];
$Username_tf=$_POST['Username_tf'];
$Password_tf=$_POST['Password_tf'];
$FName_tf=$_POST['FName_tf'];
$LName_tf= $_POST['LName_tf'];
$EmailId_tf=$_POST['EmailId_tf'];
$Contact_tf=$_POST['Contact_tf'];


 
$query  = " UPDATE USER_ACCOUNT
SET AccountUsername= '$Username_tf', FirstName='$FName_tf',LastName='$LName_tf',EmailId='$EmailId_tf'   
WHERE AccountId= $AccountId " ;

$stmt = sqlsrv_query( $conn, $query );

if( $stmt === false) {

    die( print_r( sqlsrv_errors(), true) );

}

// echo " <p>Name - {$_POST['name']} </p> <br/> ";
// echo " <p>Email - {$_POST['email']} </p> <br/>";
// echo " <p>Phone number - {$_POST['phone']} </p> <br/>";
// echo " <p>Address - {$_POST['address']} </p> <br/>";

echo "<a href='login.php'>Go to Main Login</a><br/>";


?>

<body style="background-color:#F7FF93">
<h2>We used following query - <?php echo($query) ?> </h2>
</body>

</html>