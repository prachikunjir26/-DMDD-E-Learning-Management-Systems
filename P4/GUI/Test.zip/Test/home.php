<html>
<body style="background: #FFFBE7; padding-top: 40px; font-family: Helvetica">
								 <center>
                                 <div style='margin-left: -13px;
                                    margin-right: -14px;
                                    margin-top:-48px;
                                    border-radius: 0px;
                                    display: flex;
                                    color: #fff;
                                    background: #40DFEF;
                                    align-items: center;
                                    justify-content: center;'>
								 <h2>Welcome To Elearning</h2>
                                </div>
    
								 <br/>
								 <br/>
                                 <div style='border: 1px solid #ccc; width: 40%; margin 0 auto;  border-radius: 10px; display: flex; color: #fff; background: #61A4BC; align-items: center;justify-content: center;'>
                                 <a style="text-decoration: none; color: #fff; letter-spacing: 1px; line-height: 2; text-align: center"  href='addstudent.php'><h2>Add User Account</h2></a><br>
                                 
                                 </div>
                                 <div style='border: 1px solid #ccc; width: 40%; margin 0 auto;  border-radius: 10px; display: flex; color: #fff; background: #61A4BC; align-items: center;justify-content: center;'>
                                 <a style="text-decoration: none; color: #fff; letter-spacing: 1px; line-height: 2; text-align: center"  href='instructor.php'><h2>Go to Intructor</h2></a>
                                 
                                 </div>
                                 <form style="margin-top: 30px" action='search_Patient.php' method='get'>
                                 <input style="border: none; width: 400px; height: 30px; border-radius: 5px; padding: 5px; margin-right: 10px"  type ='text' placeholder="Enter Patient Details" name='searchtext'>
								 <input style="border: none;
                                               width: 100px;
                                               height: 30px;
                                               border-radius: 5px;
                                               padding: 5px;
                                               background: #6c757d;
                                               letter-spacing: 0.5px;
                                               font-weight: bold;
                                               color: #fff;" type='submit' value='Search'>
								 <!--<a href='add_insurance.php'><h2>Add Insurance Details</h2></a>-->
								 </form>
                                 <center>
                                 </body>
                                 
</html>