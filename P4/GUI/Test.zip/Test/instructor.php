<?php
?>
<html>
    <body style="background: #FFFBE7; padding-top: 40px; padding-left: 380px; font-family: Helvetica; width:50%;"></body>
<form action="insert.php" method="post">
<h3>Welcome Instructor</h3>
</div>
    <div style='border: 1px solid #ccc; width: 40%; margin 0 auto;  border-radius: 10px; display: flex; color: #fff; background: #61A4BC; align-items: center;justify-content: center;'>
    <a style="text-decoration: none; color: #fff; letter-spacing: 1px; line-height: 2; text-align: center"  href='course.php'><h2>Add Course <Details></Details></h2></a>
    
    </div>

</form>
</html>






