<html>
<body style="background: #efe5dc; padding-top: 40px; font-family: Helvetica">
								 <center>
								 <h2>Manage User</h2>
								 <br/>
								 <br/>
                                 <div style='border: 1px solid #ccc; width: 40%; margin 0 auto;  border-radius: 10px; display: flex; color: #fff; background: #013a63; align-items: center;
                                                                                                                                                                                                        justify-content: center;'>
                                 <a style="text-decoration: none; color: #fff; letter-spacing: 1px; line-height: 2; text-align: center"  href='addstudent.php'><h2>Add student Details</h2></a>
                                 </div>
                                
                                 <center>
                                 </body>
</html>